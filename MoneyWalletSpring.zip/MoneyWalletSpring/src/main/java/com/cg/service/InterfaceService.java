package com.cg.service;

import org.springframework.context.ApplicationContext;

import com.cg.ExceptionClass.LowBalanceException;
import com.cg.ExceptionClass.NegativeAmountException;
import com.cg.ExceptionClass.SenderReceiverSameException;
import com.cg.bean.Customer;

public interface InterfaceService {

	// declaring regex for all inputs
	String userNamePattern = "[A-Z][a-z]{2,9}";
	String emailPattern = "^(.+)@(.+)$";
	String mobNoPattern = "(0/91)?[7-9][0-9]{9}";
	String paswordPattern = "(?=^.{8,}$)((?=.*\\d)|(?=.*\\W+))(?![.\n])(?=.*[A-Z])(?=.*[a-z]).*$";
	String amountPattern = "[0-9]{1,9}";

	// declaring abstract methods
	boolean validateName(String name);

	boolean validateAmount(String amount);

	boolean validateEmail(String email);

	boolean validateMobNo(String mobNo);

	boolean validatePassword(String password);

	String deposit(Customer customer, double amount)
			throws NegativeAmountException;

	String withdraw(Customer customer, double amount)
			throws LowBalanceException;

	Customer login(long mobNo, String password);

	double showBalance(Customer customer);

	String insertCustomer(Customer customer);

	void printTransaction(long mobNo);

	Customer checkUser(long parseLong);

	String fundTransfer(Customer validatedUser, Customer validatedReceiver, double parseDouble) throws SenderReceiverSameException, LowBalanceException, NegativeAmountException;
	
	public void initializeDao(ApplicationContext ctx);
}
