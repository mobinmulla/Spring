package com.cg.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Product;

@Repository
public class ProductRepoImp implements ProductRepo {

	@PersistenceContext(unitName="SpringJPA")
	private EntityManager entityManager;
	
	@Transactional(propagation= Propagation.REQUIRED)
	public void saveProduct(Product product) {
		entityManager.persist(product);

	}
	
	@Transactional(propagation= Propagation.SUPPORTS)
	public Product get(int id) {
		// TODO Auto-generated method stub
		return entityManager.find(Product.class, id);
	}

	@Transactional
	public List<Product> getAll() {
		// TODO Auto-generated method stub
		return entityManager.createQuery("from Producr").getResultList();
	}

}
