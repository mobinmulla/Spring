package com.cg.service;

import com.cg.model.Trainee;

public interface ITraineeService {
	public void add(Trainee trainee) ;

}
