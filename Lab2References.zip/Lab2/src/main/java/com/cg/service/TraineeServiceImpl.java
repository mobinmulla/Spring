package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.model.Trainee;
import com.cg.repo.TraineeRepo;

@Service("service")
public class TraineeServiceImpl implements ITraineeService {

	@Autowired
	TraineeRepo repo;
	
	public void add(Trainee trainee) {
		repo.add(trainee);
	}

	

}
