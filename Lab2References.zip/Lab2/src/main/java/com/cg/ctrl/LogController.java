package com.cg.ctrl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.model.Trainee;
import com.cg.service.TraineeServiceImpl;

@Controller
public class LogController {
	
	@Autowired
	TraineeServiceImpl service;
	
	ArrayList<String> domainArray;

	/*
	 * Login 
	 */
	@RequestMapping(value = "checklogin")
	public String logInPage(@RequestParam("username") String n, @RequestParam("password") String pass, Model m) {
		if (n.equals("admin") && pass.equals("admin")) {
			return "traineeFunctoins";
		} else {
			m.addAttribute("Invalid", "Invalid Login");
			return "login";
		}
	}
	@RequestMapping("/login")
	public String login() {
		return "login";
	}
	
	/*
	 * Adding new trainee
	 */

	@RequestMapping("/addTrainee")
	public String addTrainee(Model model) {
		domainArray = new ArrayList<String>();
		domainArray.add("Java Cloud");
		domainArray.add("Dot Net");
		domainArray.add("JEE Full Stack");

		model.addAttribute("domainArray", domainArray);

		model.addAttribute("trainee", new Trainee());
		return "addTrainee";
	}

	@RequestMapping("/addTraineeData")
	public String add(@ModelAttribute("trainee") Trainee trainee,Model model) {
		service.add(trainee);
		return "Trainee data added...!!!!";
	}
	
	
	@RequestMapping("/deleteTrainee")
	public String deleteTrainee() {
		return "deleteTrainee";
	}

	@RequestMapping("/modifyTrainee")
	public String modifyTrainee() {
		return "modifyOperation";
	}

	@RequestMapping("/retrieveTrainee")
	public String retrieveTrainee() {
		return "retrieveOperation";
	}

}
