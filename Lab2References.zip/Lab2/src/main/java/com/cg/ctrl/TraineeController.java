package com.cg.ctrl;

import java.util.ArrayList;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;


@Scope("session")
@Controller
@RequestMapping(value= "trainee")
public class TraineeController {
	
	ArrayList<String> domain;
/*	@RequestMapping("/addTrainee")
	public String addTrainee() {
		return "addTrainee";
	}*/
	
/*	@RequestMapping("/addTraineeData")
	public String addTraineeData(@ModelAttribute("trainee") BindingResult result, Model model) {
		domain = new ArrayList<String>();
		model.addAttribute("trainee", new Trainee());
	domain.add("Java Cloud");
		domain.add("Dot Net");
		domain.add("JEE Full Stack");
		model.addAttribute("domain", domain);
		return "trainee";
	}*/
	
}
