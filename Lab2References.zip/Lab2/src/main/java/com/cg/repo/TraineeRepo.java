package com.cg.repo;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.model.Trainee;

@Repository
@Transactional
public class TraineeRepo implements ITraineeRepo {

	@PersistenceContext(unitName="JPA-PU")
	private EntityManager entityManager;
	
	public void add(Trainee trainee) {
		entityManager.persist(trainee);
		
	}

}
