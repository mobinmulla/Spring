package com.cg.repo;

import com.cg.model.Trainee;

public interface ITraineeRepo {

	public void add(Trainee trainee);
}
