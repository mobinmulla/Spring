package com.cg.dao;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Repository;

import com.cg.ExceptionClass.LowBalanceException;
import com.cg.ExceptionClass.NegativeAmountException;
import com.cg.ExceptionClass.SenderReceiverSameException;
import com.cg.bean.Customer;
import com.cg.bean.Transaction;

@Repository("dao")
public class ClassDao implements InterfaceDao {

	Map<Long, Customer> customerMap = new HashMap<Long, Customer>();
	ArrayList<Transaction> tranArray = new ArrayList<Transaction>();
	Transaction tran;
	String message = null;
	ApplicationContext ctx;

	public ClassDao() {
		ctx = new ClassPathXmlApplicationContext("annotated.xml");
	}

	public void initDao(ApplicationContext ctx) {

	}

	public void prepareThings() {
		ctx = new ClassPathXmlApplicationContext("annotated.xml");
	}

	public String withdraw(Customer customer, double amount) throws LowBalanceException {

		if (amount > customer.getBalance()) {

			throw new LowBalanceException("Your balance is low");

		} else {

			customer.setBalance(customer.getBalance() - amount);

			tran = (Transaction) ctx.getBean("transaction");
			tran.setType("debit");
			tran.setAmount(amount);
			tran.setBalance(customer.getBalance());
			tran.setMobNo(customer.getMobileNo());
			tranArray.add(tran);

			message = "Amount " + amount + " for mobile no: " + customer.getMobileNo() + "\n Your updated balance is: "
					+ showBalance(customer);
			return message;
		}

	}

	public Customer login(long mobNo, String password) {

		for (Long key : customerMap.keySet()) {
			if (key == mobNo && customerMap.get(key).getPassword().equals(password)) {
				return customerMap.get(key);
			}
		}
		return null;
	}

	public String insertCustomer(Customer customer) {

		customerMap.put(customer.getMobileNo(), customer);
		return "User data saved" + customer.getMobileNo();

	}

	public double showBalance(Customer customer) {
		return customer.getBalance();

	}

	public String fundTransfer(Customer senderCustomer, Customer receiverCustomer, Double amount)
			throws SenderReceiverSameException, LowBalanceException, NegativeAmountException {
		if (senderCustomer.getMobileNo() == receiverCustomer.getMobileNo()) {

			throw new SenderReceiverSameException("Cannot send to yourself");

		} else {
			withdraw(senderCustomer, amount);
			deposit(receiverCustomer, amount);
			message = amount + " amount transferred to mobile number: " + receiverCustomer.getMobileNo()
					+ "\n Your updated balance is: " + showBalance(senderCustomer);
			return message;
		}
	}

	public Customer checkUser(long receiverMobNo) {
		for (Long key : customerMap.keySet()) {
			if (receiverMobNo == customerMap.get(key).getMobileNo()) {
				return customerMap.get(key);
			}
		}
		return null;
	}

	public void printTransaction(long mobNo) {

		if (tranArray.isEmpty()) {
			System.out.println("No transactions performed yet!!");
		}
		for (Transaction t : tranArray) {
			if (t.getMobNo() == mobNo) {
				System.out.println(t.toString());
			}
		}
	}

	public String deposit(Customer customer, double amount) throws NegativeAmountException {
		if (amount <= 0) {

			message = null;
			throw new NegativeAmountException("Please enter amount greater than 0");

		} else {

			customer.setBalance(customer.getBalance() + amount);

			tran = (Transaction) ctx.getBean("transaction");
			tran.setType("credit");
			tran.setAmount(amount);
			tran.setBalance(customer.getBalance());
			tran.setMobNo(customer.getMobileNo());
			tranArray.add(tran);

			message = "Amount " + amount + "  for mobile no: " + customer.getMobileNo() + "\n Your updated balance is: "
					+ showBalance(customer);
			return message;
		}

	}

}
