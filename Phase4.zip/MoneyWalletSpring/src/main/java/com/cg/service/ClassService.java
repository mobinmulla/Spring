package com.cg.service;

import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Service;

import com.cg.ExceptionClass.LowBalanceException;
import com.cg.ExceptionClass.NegativeAmountException;
import com.cg.ExceptionClass.SenderReceiverSameException;
import com.cg.bean.Customer;
import com.cg.dao.ClassDao;
import com.cg.dao.InterfaceDao;

@Service("service")
public class ClassService implements InterfaceService {


	InterfaceDao idao  = new ClassDao();

	public void initializeDao(ApplicationContext ctx) {

	}
	
	public boolean validateName(String name) {

		if (name.matches(userNamePattern)) { // user name regex validation
			return true;
		} else
			return false;
	}

	
	public boolean validateEmail(String email) {
		if (email.matches(emailPattern)) { // email regex validation
			return true;
		} else
			return false;
	}

	
	public boolean validateMobNo(String mobNo) {
		if (mobNo.matches(mobNoPattern)) { // mobile no regex validation
			return true;
		} else
			return false;
	}

	
	public String deposit(Customer customer, double amount)
			throws NegativeAmountException {
		return (idao.deposit(customer, amount)); 

	}

	
	public String withdraw(Customer customer, double amount)
			throws LowBalanceException {
		return (idao.withdraw(customer, amount));

	}

	
	public Customer login(long mobNo, String password) {
//		prepareThings();
		
		return (idao.login(mobNo, password)); 
	}

	
	public boolean validatePassword(String password) {
		if (password.matches(paswordPattern)) { 
			return true;
		} else
			return false;
	}

	
	public String insertCustomer(Customer customer) {
		return (idao.insertCustomer(customer)); 

	}

	
	public double showBalance(Customer customer) {
		return idao.showBalance(customer); 
	}

	


	
	public Customer checkUser(long receiverMobNo) {
		return (idao.checkUser(receiverMobNo)); 
	}

	
	public void printTransaction(long mobNo) {
		idao.printTransaction(mobNo); 
	}

	
	public boolean validateAmount(String amount) {
		if (amount.matches(amountPattern)) { 
			return true;
		} else
			return false;
	}


	public String fundTransfer(Customer validatedUser, Customer validatedReceiver, double parseDouble) throws SenderReceiverSameException, LowBalanceException, NegativeAmountException {
		return (idao.fundTransfer(validatedUser, validatedReceiver, parseDouble)); 
	}

	

}
