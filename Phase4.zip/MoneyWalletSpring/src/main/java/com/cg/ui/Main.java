package com.cg.ui;

import java.util.Scanner;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.ExceptionClass.CustomerExistsException;
import com.cg.ExceptionClass.InvalidCredentialsException;
import com.cg.ExceptionClass.InvalidReceiverException;
import com.cg.ExceptionClass.LowBalanceException;
import com.cg.ExceptionClass.NegativeAmountException;
import com.cg.ExceptionClass.SenderReceiverSameException;
import com.cg.bean.Customer;
import com.cg.service.ClassService;
import com.cg.service.InterfaceService;

public class Main { // implements ApplicationContextAware {

	public static void main(String[] args) {

		InterfaceService is;

		Scanner sc = new Scanner(System.in);
		String choice, password, currentLoginPassword, email, mobNo, currentLoginMobNo;
		boolean isValid, isLogout = false;
		Customer validatedUser, validatedReceiver, customerExists;
		double custId = 1;
		String amount, transferAmount;
		String messageToDisplay;
		is = new ClassService();
		Customer customer;

		for (;;) {
			// Home page
			System.out.println("Weclcome to DTM wallet");
			System.out.println("1) Register");
			System.out.println("2) Login");
			choice = sc.next();
			if (choice.equals("1")) {
				customer = new Customer();
				while (true) {
					// Registration page
					System.out.println("Enter Name: ");
					String name = sc.next();
					isValid = is.validateName(name);
					if (isValid) {
						customer.setName(name);
						break;
					}
					System.out.println("Name should contain only alphabets & only first letter should be capital");
				}
				while (true) {
					System.out.println("Enter Mobile Number: ");
					mobNo = sc.next();
					isValid = is.validateMobNo(mobNo);
					if (isValid) {
						customer.setMobileNo(Long.parseLong(mobNo));
						break;
					}
					System.out.println("Mobile number should be 10 digits and start with 7/8/9");
				}
				while (true) {
					System.out.println("Enter password: ");

					password = sc.next();
					isValid = is.validatePassword(password);
					if (isValid) {
						customer.setPassword(password);
						break;
					}
					System.out.println(
							"Password should be 8 characters, should contain at least one special character, digit and one uppercase letter");
				}
				while (true) {
					System.out.println("Enter Email Id: ");
					email = sc.next();
					isValid = is.validateEmail(email);
					if (isValid) {
						customer.setEmail(email); 
						break;
					}
					System.out.println("Invalid email");
				}

				customerExists = is.checkUser(Long.parseLong(mobNo));
				if (customerExists != null) {
					try {
						throw new CustomerExistsException("There is already an account for this mobile number");
					} catch (CustomerExistsException e) {
						e.printStackTrace();
					}
				}
				customer.setCustId(custId);
				custId++;
				is.insertCustomer(customer);

			} else {
				// login page
				while (true) {
					System.out.println("Enter Mobile Number: ");

					currentLoginMobNo = sc.next();
					isValid = is.validateMobNo(currentLoginMobNo);
					if (isValid) {
						break;
					}
				}
				while (true) {
					System.out.println("Enter password: ");
					currentLoginPassword = sc.next();
					isValid = is.validatePassword(currentLoginPassword);
					if (isValid) {
						break;
					}
				}
				validatedUser = is.login(Long.parseLong(currentLoginMobNo),
						currentLoginPassword);

				if (validatedUser != null) { 
					System.out.println("Welcome");
					while (true) {
						System.out.println("1) Show Balance");
						System.out.println("2) Deposit");
						System.out.println("3) Withdraw");
						System.out.println("4) Fund Transfer");
						System.out.println("5) Print Transactions");
						System.out.println("6) Log out");
						choice = sc.next();

						switch (choice) {

						case "1": 
							System.out.println("Your balance is: " + is.showBalance(validatedUser));
							break;

						case "2": 
							try {
								while (true) {
									System.out.println("How much amount you want to deposit?"); 

									amount = sc.next();
									isValid = is.validateAmount(amount);
									if (isValid) {
										break;
									}
									System.out.println("Amount should be minimum 1 and maximum 999999999");
								}

								messageToDisplay = is.deposit(validatedUser, Double.parseDouble(amount));
								System.out.println(messageToDisplay);
							} catch (NumberFormatException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							} catch (NegativeAmountException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}

							
							break;

						case "3": 
							try {
								while (true) {
									System.out.println("How much amount you want to deposit?"); 
									
									amount = sc.next();
									isValid = is.validateAmount(amount);
									if (isValid) {
										break;
									}
									System.out.println("Amount should be minimum 1 and maximum 999999999");
								}

								messageToDisplay = is.withdraw(validatedUser, Double.parseDouble(amount));
								System.out.println(messageToDisplay);
							} catch (NumberFormatException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							} catch (LowBalanceException e1) {
								// TODO Auto-generated catch block
								e1.printStackTrace();
							}

							break;

						case "4":
							System.out.println("Enter the mobile number of receiver: ");
							long receiverMobNo = sc.nextLong();
							validatedReceiver = is.checkUser(receiverMobNo);
							if (validatedReceiver != null) {
								try {
									while (true) {
										System.out.println("How much amount you want to deposit?"); 

										transferAmount = sc.next();
										isValid = is.validateAmount(transferAmount);
										if (isValid) {
											break;
										}
										System.out.println("Amount should be minimum 1 and maximum 999999999");
									}

									messageToDisplay = is.fundTransfer(validatedUser, validatedReceiver,
											Double.parseDouble(transferAmount));
									System.out.println(messageToDisplay);
								} catch (NumberFormatException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								} catch (SenderReceiverSameException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								} catch (LowBalanceException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								} catch (NegativeAmountException e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}

							} else {
								try {
									throw new InvalidReceiverException("Invalid mobile number of receiver");
								} catch (InvalidReceiverException e) {
									e.printStackTrace();
								}
							}
							break;

						case "5": 
							is.printTransaction(Long.parseLong(currentLoginMobNo));
							break;

						case "6": 
							isLogout = true;
							break;

						default: 
							System.out.println("Enter a valid choice");
						}
						if (isLogout == true) {
							isLogout = false;
							break;
						} else {
							continue;
						}
					}

				} else {
					try {
						throw new InvalidCredentialsException("Invalid username or password"); 
					} catch (InvalidCredentialsException e) {
						e.printStackTrace();
					}
				}

			}
		}
	}

}