package com.cg.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.AlbumArtist;
import com.cg.service.AlbumService;

@RestController
public class AlbumController {

	@Autowired
	private AlbumService service;

	@PostMapping("/add-album")
	public AlbumArtist addProduct(@RequestParam("name") String name, @RequestParam("price") double price,
			@RequestParam("artistName") String artistName) {
		AlbumArtist album = new AlbumArtist();
		album.setAlbumTitle(name);
		album.setAlbumPrice(price);
		album.setArtist(artistName);
		return service.addAlbum(album);
	}
	
	@PostMapping("/add")
	public AlbumArtist addProduct2(@RequestBody AlbumArtist album) {
		return service.addAlbum(album);
	}


	@GetMapping(name = "/find-album", produces = "application/json")
	public AlbumArtist getProduct(@RequestParam("fid") int id) {
		return service.getAlbum(id);

	}

	@PutMapping(name = "/update-album", produces = "application/json")
	public AlbumArtist updateProduct(@RequestParam("id") int id, @RequestParam("newName") String name,
			@RequestParam("newPrice") double price,@RequestParam("newArtistName") String artistName) {

		return service.updateAlbum(id, name, price, artistName);

	}

	@DeleteMapping(name = "/delete-album", produces = "application/json")
	public AlbumArtist deleteAlbum(@RequestParam("did") int id) {
		return service.deleteAlbum(id);

	}
	
	
}
