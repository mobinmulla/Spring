package com.cg.repo;

import org.springframework.data.repository.CrudRepository;

import com.cg.entity.AlbumArtist;

public interface AlbumRepo extends CrudRepository<AlbumArtist, Integer>{

}
