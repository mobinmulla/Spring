package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="album")
public class AlbumArtist {

	@Id
	@GeneratedValue
	@Column(name="album_id")
	private int id;
	@Column(length=20)
	private String albumTitle;
	@Column(length=20)
	private double albumPrice;
	@Column(length=20)
	private String artist;
	public AlbumArtist(int id, String albumTitle, double albumPrice, String artist) {
		super();
		this.id = id;
		this.albumTitle = albumTitle;
		this.albumPrice = albumPrice;
		this.artist = artist;
	}
	
	
	public AlbumArtist() {
		
	}


	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAlbumTitle() {
		return albumTitle;
	}
	public void setAlbumTitle(String albumTitle) {
		this.albumTitle = albumTitle;
	}
	public double getAlbumPrice() {
		return albumPrice;
	}
	public void setAlbumPrice(double albumPrice) {
		this.albumPrice = albumPrice;
	}
	public String getArtist() {
		return artist;
	}
	public void setArtist(String artist) {
		this.artist = artist;
	}
	
	
}
