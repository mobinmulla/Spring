package com.cg.service;

import com.cg.entity.AlbumArtist;

public interface AlbumService {
	
	public AlbumArtist addAlbum(AlbumArtist album);
	
	public AlbumArtist getAlbum(int id);
	
	public AlbumArtist updateAlbum(int id, String name, double price, String artist);
	
	public AlbumArtist deleteAlbum(int id);
	
	public Iterable<AlbumArtist> getAllAlbum();

	

}
