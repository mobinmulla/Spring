package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.AlbumArtist;
import com.cg.repo.AlbumRepo;

@Service
@Transactional
public class AlbumServiceImpl implements AlbumService {

	@Autowired
	AlbumRepo repo;

	public AlbumArtist addAlbum(AlbumArtist album) {
		repo.save(album);
		return album;

	}

	public AlbumArtist getAlbum(int id) {
		return repo.findById(id).get();
	}

	public AlbumArtist updateAlbum(int id, String name, double price, String artist) {
		AlbumArtist album = repo.findById(id).get();
		album.setAlbumTitle(name);
		album.setAlbumPrice(price);
		album.setArtist(artist);
		repo.save(album);
		return album;
	}

	public AlbumArtist deleteAlbum(int id) {
		AlbumArtist album = repo.findById(id).get();
		repo.delete(album);
		return album;
	}

	@Override
	public Iterable<AlbumArtist> getAllAlbum() {
		return repo.findAll();
	}

	
}
