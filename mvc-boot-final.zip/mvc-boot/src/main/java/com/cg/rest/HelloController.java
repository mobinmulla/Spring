package com.cg.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Product;
import com.cg.service.ProductService;


@RestController
public class HelloController {
	
	@Autowired
	private ProductService service;
	
	@GetMapping("/hola")
	public String hello() {
		return "Hello";
	}


	@PostMapping("/addproduct")
	public String addProduct(@RequestParam("name") String name , @RequestParam("price") double price){
		Product product = new Product();
		product.setName(name);
		product.setPrice(price);
		service.saveProduct(product);
		
		return "Saved";
	}
	
	@GetMapping(name="/find", produces="application/json")
	public Product getProduct(@RequestParam("pid") int id) {
		return service.get(id);
		
	}
	
	@PutMapping(name="/update", produces= "application/json")
	public String updateProduct(@RequestParam("id") int id, @RequestParam("newName") String name, @RequestParam("newPrice") double price) {
		service.updateProduct(id,name,price);
		return "Update";
		
	}
	
	@DeleteMapping(name="/delete",produces="application/json")
	public Product deleteProduct(@RequestParam("did") int id) {
		return service.deleteProduct(id);
	//	return "Deleted";
		
	}
}
