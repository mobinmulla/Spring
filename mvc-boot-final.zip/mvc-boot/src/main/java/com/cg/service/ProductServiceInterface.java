package com.cg.service;

import com.cg.entity.Product;

public interface ProductServiceInterface {
	
	public Product saveProduct(Product product);
	
	public Product get(int id);
	
	public Product updateProduct(int id, String name, double price);
	
	public Product deleteProduct(int id);

}
