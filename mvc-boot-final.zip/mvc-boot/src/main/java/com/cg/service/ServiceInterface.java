package com.cg.service;

import com.cg.entity.Product;

public interface ServiceInterface {
	
	public Product saveProduct(Product product);
	
	public Product get(int id);
	
	public Product updateProduct(int id, String name, double price);
	
	public void deleteProduct(int id);

}
