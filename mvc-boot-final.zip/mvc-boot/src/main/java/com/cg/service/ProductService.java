package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.Product;
import com.cg.repo.ProductRepo;

@Service
@Transactional
public class ProductService implements ProductServiceInterface {

	@Autowired
	private ProductRepo repo;

	@Override
	public Product saveProduct(Product product) {
		repo.save(product);
		return product;

	}

	@Override
	public Product get(int id) {
		 return repo.findById(id).get();
		 

	}

	@Override
	public Product updateProduct(int id, String name, double price) {
		Product product = repo.findById(id).get();
		product.setName(name);
		product.setPrice(price);
		repo.save(product);
		return product;
	}

	public Product deleteProduct(int id) {
		 Product product = repo.findById(id).get();
		 repo.delete(product);
		 return product;
	}

}
